main.py is the script to run for f-test and classification using feature_selection.

It uses the sckit classifier methods for classification.

to run >> python main.py
